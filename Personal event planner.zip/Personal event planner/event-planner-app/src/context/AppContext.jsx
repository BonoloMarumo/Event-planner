import { createContext, useState } from "react";

export const AppcContext = createContext();

export const AppcProvider = ({ children }) => {
    const [events, setEvents] = useState([]);

    const addEvent = (event) => setEvents([...events, event]);
    const updateEvent = (id, updatedEvent) => {
        setEvents(events.map(event => event.id === id ? updatedEvent : event));
    };
    const deleteEvent = (id) => setEvents(events.filter(event => event.id !== id));

    return (
        <AppcContext.Provider value={{ events, addEvent, updateEvent, deleteEvent }}>
            {children}
        </AppcContext.Provider>
    );
};


