import React, { createContext, useState } from 'react';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // Initialize events with default sample data
  const [events, setEvents] = useState([
    {
      name: "Team Meeting",
      date: "2025-04-25",
      time: "10:00 AM",
      location: "Conference Room 1",
      description: "Discuss quarterly goals.",
    },
    {
      name: "Lunch with Sarah",
      date: "2025-04-26",
      time: "12:30 PM",
      location: "Downtown Café",
      description: "Catch up and discuss potential collaboration.",
    },
  ]);

  return (
    <AppContext.Provider value={{ user, setUser, events, setEvents }}>
      {children}
    </AppContext.Provider>
  );
};

