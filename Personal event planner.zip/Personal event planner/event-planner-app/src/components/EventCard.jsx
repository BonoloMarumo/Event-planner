import { useContext } from "react";
import { AppcContext } from "../context/AppContext";


const EventCard = ({ event }) => {
    const { deleteEvent } = useContext(AppcContext);

    return (
        <div className="event-card">
            <h3>{event.name}</h3>
            <p>{event.date} at {event.time}</p>
            <p>Location: {event.location}</p>
            <p>{event.description}</p>
            <button onClick={() => deleteEvent(event.id)}>Delete</button>
        </div>
    );
};

export default EventCard;


