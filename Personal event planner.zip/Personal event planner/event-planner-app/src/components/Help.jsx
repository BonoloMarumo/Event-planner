const Help = () => {
  return (
      <div>
          <h2>Help Guide</h2>
          <p>Welcome to the Event Planner App! Here's how to use it:</p>
          <ul>
              <li>Register and log in to access your events.</li>
              <li>Use 'Add Event' to schedule new events.</li>
              <li>Edit or delete events from the dashboard.</li>
              <li>Navigate using the menu at the top.</li>
          </ul>
      </div>
  );
};

export default Help;

