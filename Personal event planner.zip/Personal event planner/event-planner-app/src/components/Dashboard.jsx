import React, { useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { Container, Row, Col } from 'react-bootstrap';
import EventCard from './EventCard';

const Dashboard = () => {
  const { events } = useContext(AppContext);

  return (
    <Container className="dashboard">
      <h2 className="text-center">Your Upcoming Events</h2>
      <Row>
        {events && events.length > 0 ? (
          events.map((event, index) => (
            <Col key={index} xs={12} md={6} lg={4}>
              <EventCard event={event} />
            </Col>
          ))
        ) : (
          <p className="text-center">No events scheduled. Please add some events!</p>
        )}
      </Row>
    </Container>
  );
};

export default Dashboard;



