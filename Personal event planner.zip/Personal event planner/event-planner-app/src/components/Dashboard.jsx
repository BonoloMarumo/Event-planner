import { useContext } from "react";
import { AppcContext } from "../context/AppContext";
import EventCard from "../components/EventCard";
import "../styles.css";


const Dashboard = () => {
    const { events } = useContext(AppcContext);

    return (
        <div>
            <h2>Upcoming Events</h2>
            {events.length === 0 ? <p>No events scheduled.</p> : (
                <div>
                    {events.map(event => <EventCard key={event.id} event={event} />)}
                </div>
            )}
        </div>
    );
};

export default Dashboard;




