import { useState, useContext } from "react";
import { AppcContext } from "../context/AppContext";

const AddEvent = () => {
    const { addEvent } = useContext(AppcContext);
    const [event, setEvent] = useState({ name: "", date: "", time: "", description: "", location: "" });

    const handleSubmit = (e) => {
        e.preventDefault();
        addEvent({ ...event, id: Date.now() });
        setEvent({ name: "", date: "", time: "", description: "", location: "" });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Event Name" value={event.name} onChange={(e) => setEvent({...event, name: e.target.value})} required />
            <input type="date" value={event.date} onChange={(e) => setEvent({...event, date: e.target.value})} required />
            <input type="time" value={event.time} onChange={(e) => setEvent({...event, time: e.target.value})} required />
            <input type="text" placeholder="Location" value={event.location} onChange={(e) => setEvent({...event, location: e.target.value})} required />
            <textarea placeholder="Description" value={event.description} onChange={(e) => setEvent({...event, description: e.target.value})}></textarea>
            <button type="submit">Add Event</button>
        </form>
    );
};

export default AddEvent;


