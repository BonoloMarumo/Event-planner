import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AppcProvider } from "./context/AppContext";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";
import Help from "./components/Help";
import AddEvent from "./components/AddEvent";
import ErrorBoundary from "./ErrorBoundary";
import "./styles.css";


const App = () => {
    return (
        <AppcProvider>
            <Router>
                <Header />
                <ErrorBoundary>
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/add-event" element={<AddEvent />} />
                        <Route path="/help" element={<Help />} />
                    </Routes>
                </ErrorBoundary>
            </Router>
        </AppcProvider>
    );
};

export default App;



