import React from 'react';

const Help = () => {
  return (
    <div className="help">
      <h1>Help</h1>
      
      <section>
        <h2>Welcome to Event Planner</h2>
        <p>
          This app helps you organize and manage personal or professional events, such as appointments, meetings, or social gatherings.
        </p>
      </section>

      <section>
        <h2>How to Get Started</h2>
        <ol>
          <li>
            <strong>Register:</strong> Click "Register" and fill in your name, email, username, and password.
          </li>
          <li>
            <strong>Log In:</strong> Use your username and password to log in.
          </li>
        </ol>
      </section>

      <section>
        <h2>Dashboard Overview</h2>
        <p>
          View your upcoming events in a list or calendar format. Use the navigation menu to go to "Add Event" or "Help."
        </p>
      </section>

      <section>
        <h2>Adding a New Event</h2>
        <p>
          Navigate to "Add Event," fill in the event details (name, date, time, location, and description), and click "Save" to add the event.
        </p>
      </section>

      <section>
        <h2>Editing or Deleting Events</h2>
        <ul>
          <li>
            <strong>To Edit:</strong> Select an event, update the details, and save the changes.
          </li>
          <li>
            <strong>To Delete:</strong> Select an event and click "Delete."
          </li>
        </ul>
      </section>

      <section>
        <h2>Tips for Organizing Events</h2>
        <p>
          Use descriptive names for events and update your dashboard regularly to stay organized.
        </p>
      </section>

      <section>
        <h2>Troubleshooting</h2>
        <ul>
          <li>
            <strong>Can't log in?</strong> Ensure your email and password are correct.
          </li>
          <li>
            <strong>Events not saving?</strong> Check your internet connection.
          </li>
        </ul>
      </section>

      <section>
        <h2>Contact Support</h2>
        <p>
          If you need help, contact our support team at <a href="nolimarumo@gmail.com">nolimarumo@gmail.com</a>.
        </p>
      </section>
    </div>
  );
};

export default Help;
