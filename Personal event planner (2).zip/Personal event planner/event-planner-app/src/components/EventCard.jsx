import React from 'react';
import { Card } from 'react-bootstrap';

const EventCard = ({ event }) => {
  if (!event || !event.name || !event.date || !event.time || !event.location || !event.description) {
    return (
      <Card className="event-card">
        <Card.Body>Invalid event data</Card.Body>
      </Card>
    );
  }

  return (
    <Card className="event-card">
      <Card.Body>
        <Card.Title>{event.name}</Card.Title>
        <Card.Subtitle className="mb-2 text-muted">
          {event.date} at {event.time}
        </Card.Subtitle>
        <Card.Text>{event.description}</Card.Text>
        <Card.Text>
          <strong>Location:</strong> {event.location}
        </Card.Text>
      </Card.Body>
    </Card>
  );
};

export default EventCard;

