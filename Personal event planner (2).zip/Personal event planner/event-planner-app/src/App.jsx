import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import AddEvent from './components/AddEvent';
import Help from './components/Help';
import { AppProvider } from './context/AppContext';
import './App.css';
import ErrorBoundary from './ErrorBoundary.jsx';




const App = () => (
  <ErrorBoundary>
  <AppProvider>
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Dashboard />} /> {/* Default route */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/add-event" element={<AddEvent />} />
        <Route path="/help" element={<Help />} /> {/* Ensure this route exists */}
      </Routes>
    </Router>
  </AppProvider>
  </ErrorBoundary>
);

export default App;


